﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.IO;
//using iTextSharp.text;
//using iTextSharp.text.pdf;
//using System.Transactions;

namespace SneakPeak
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {

        DataClasses1DataContext db = new DataClasses1DataContext();
        

        public Sneaker getSneaker(int Sneaker_id)
        {

            var sneaker = (from s in db.Sneakers
                           where s.sneaker_id.Equals(Sneaker_id)
                           select s).FirstOrDefault();
            return sneaker;
        }

        public List<Sneaker> getSneakers()
        {
            throw new NotImplementedException();
        }



        public int Login(string email, string password)
        {
            var user = (from u in db.Users
                        where u.email == email && u.password == password
                        select u).FirstOrDefault();

            if (user != null)
            {
                return user.user_id;
            }
            else
            {
                return -1;
            }
        }


        public User getUser(int userId)
        {
            var userQuery = from u in db.Users
                            where u.user_id == userId
                            select u;

            return userQuery.FirstOrDefault();
        }


        public bool Register(string firstname, string lastname, string email, string password, String phone_no, string userType)
        {
            //checks existing user 
            var existingUserQuery = from u in db.Users
                                    where u.email == email
                                    select u;

            if (existingUserQuery.Any()) return false;

            //create a new user
            User newUser = new User
            {
                first_name = firstname,
                last_name = lastname,
                phone_number = phone_no,
                email = email,
                password = password,
                user_type = userType,
            };

            db.Users.InsertOnSubmit(newUser);
            db.SubmitChanges();
            return true;
        }




        //Get single product using ID

        //Get cart item
        public CartItem GetCartItem(int Id)
        {
            return (from s in db.CartItems
                    where s.sneaker_id == Id
                    select s).FirstOrDefault();
        }

        //Add sneker which is our product
        public bool AddSneaker(Sneaker sneaker)
        {
            var sneak = (from s in db.Sneakers
                         where s.sneaker_id.Equals(sneaker.sneaker_id)
                         select s).FirstOrDefault();

            if (sneak != null)
            {
                return false;
            }

            db.Sneakers.InsertOnSubmit(sneaker);

            try
            {
                db.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                ex.GetBaseException();
                return false;
            }
        }




        //  Create a new cart for a user if not exists
        public void CreateCart(int userId)
        {
            var cart = db.Carts.FirstOrDefault(c => c.user_id == userId);

            if (cart == null)
            {
                cart = new Cart
                {
                    user_id = userId,
                    cart_total = 0
                };

                try
                {
                    db.Carts.InsertOnSubmit(cart);
                    db.SubmitChanges();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error creating cart: " + ex.Message, ex);
                }
            }
        }

        //  Add Sneaker to Cart
        public void AddItemToCart(int userId, int sneakerId)
        {
            var cart = GetCart(userId);
            var sneaker = getSneaker(sneakerId);

            if (cart == null)
            {
                CreateCart(userId);
                cart = GetCart(userId);
            }

            var cartItem = db.CartItems.FirstOrDefault(ci => ci.sneaker_id == sneakerId && ci.cart_id == cart.cart_id);

            if (cartItem == null)
            {
                cartItem = new CartItem
                {
                    cart_id = cart.cart_id,
                    sneaker_id = sneakerId,
                    quantity = 1,
                    total_price = sneaker.retail_price
                };

                db.CartItems.InsertOnSubmit(cartItem);
                cart.cart_total += sneaker.retail_price;
            }
            else
            {
                cartItem.quantity += 1;
                cartItem.total_price = cartItem.quantity * sneaker.retail_price;
                cart.cart_total += sneaker.retail_price;
            }

            try
            {
                db.SubmitChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("Error adding item to cart: " + ex.Message, ex);
            }
        }

        //  Get all items in a user's cart
        public List<CartItem> GetCartItems(int cartId)
        {
            return db.CartItems.Where(ci => ci.cart_id == cartId).ToList();
        }

        //  Remove a sneaker from the cart
        public void RemoveItemFromCart(int userId, int sneakerId)
        {
            var cart = GetCart(userId);
            var cartItem = db.CartItems.FirstOrDefault(ci => ci.sneaker_id == sneakerId && ci.cart_id == cart.cart_id);

            if (cartItem != null)
            {
                cart.cart_total -= cartItem.total_price;
                db.CartItems.DeleteOnSubmit(cartItem);
                db.SubmitChanges();
            }
        }

        //  Get sneakers by category
        public List<Sneaker> getSneakersByCategory(string categoryName)
        {
            return db.Sneakers
                .Where(s => s.stock_quantity > 0 && s.Category.category_name == categoryName)
                .ToList();
        }

        //  Get cart by user ID
        public Cart GetCart(int userId)
        {
            return db.Carts.FirstOrDefault(c => c.user_id == userId);
        }

        //  Count items in cart
        public int CartItemsCount(int cartId)
        {
            return db.CartItems.Where(ci => ci.cart_id == cartId).Sum(ci => ci.quantity);
        }



        //transaction processing
        public bool Checkout(int userId)
        {
            try
            {
                // 1. Get user and cart
                var user = getUser(userId);
                var cart = GetCart(userId);

                if (user == null || cart == null || cart.cart_total <= 0)
                    throw new Exception("Invalid checkout request.");

                // 2. Get cart items
                var cartItems = GetCartItems(cart.cart_id);
                if (cartItems == null || cartItems.Count == 0)
                    throw new Exception("Cart is empty.");

                // 3. Validate stock for all items
                foreach (var item in cartItems)
                {
                    var sneaker = getSneaker(item.sneaker_id);
                    if (sneaker == null || sneaker.stock_quantity < item.quantity)
                        throw new Exception($"Insufficient stock for {sneaker?.name ?? "Unknown Sneaker"}");
                }

                // 4. Create order
                Order order = new Order
                {
                    user_id = userId,
                    order_date = DateTime.Now,
                    total_amount = cart.cart_total,
                    status = "Pending"
                };

                db.Orders.InsertOnSubmit(order);
                db.SubmitChanges(); // Order gets its ID

                // 5. Create order items and update stock
                foreach (var item in cartItems)
                {
                    var sneaker = getSneaker(item.sneaker_id);
                    sneaker.stock_quantity -= item.quantity;

                    Order_Item orderItem = new Order_Item
                    {
                        order_id = order.order_id,
                        sneaker_id = item.sneaker_id,
                        quantity = item.quantity,
                        total_price = item.total_price
                    };

                    db.Order_Items.InsertOnSubmit(orderItem);
                }

                db.SubmitChanges();

                // 6. Clear cart
                foreach (var item in cartItems)
                {
                    db.CartItems.DeleteOnSubmit(item);
                }

                cart.cart_total = 0;
                db.SubmitChanges();

                return true;
            }
            catch (Exception ex)
            {
                throw new FaultException<string>("Checkout failed: " + ex.Message);
            }
        }



        //generating the invoice
        public  byte[] GenerateInvoice(int orderId)
        {
            try
            {
                // 1. Get Order
                var order = db.Orders.FirstOrDefault(o => o.order_id == orderId);
                if (order == null)
                    throw new Exception("Order not found.");

                // 2. Get User
                var user = getUser((int)order.user_id);

                // 3. Get Order Items
                var orderItems = db.Order_Items.Where(oi => oi.order_id == orderId).ToList();

                if (orderItems.Count == 0)
                    throw new Exception("No items found for this order.");

                // 4. Create PDF Document
                //        using (MemoryStream ms = new MemoryStream())
                //        {
                //            Document doc = new Document(PageSize.A4, 50, 50, 25, 25);
                //            PdfWriter writer = PdfWriter.GetInstance(doc, ms);
                //            doc.Open();

                //            // Invoice Title
                //            Font titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18);
                //            doc.Add(new Paragraph("INVOICE", titleFont));
                //            doc.Add(new Paragraph($"Order ID: {order.order_id}", FontFactory.GetFont(FontFactory.HELVETICA, 12)));
                //            doc.Add(new Paragraph($"Date: {order.order_date}", FontFactory.GetFont(FontFactory.HELVETICA, 12)));
                //            doc.Add(new Paragraph($"Customer: {user.first_name} {user.last_name}", FontFactory.GetFont(FontFactory.HELVETICA, 12)));
                //            doc.Add(new Paragraph($"Email: {user.email}", FontFactory.GetFont(FontFactory.HELVETICA, 12)));
                //            doc.Add(new Paragraph(" "));

                //            // Table for items
                //            PdfPTable table = new PdfPTable(4);
                //            table.WidthPercentage = 100;
                //            table.AddCell("Sneaker");
                //            table.AddCell("Quantity");
                //            table.AddCell("Price");
                //            table.AddCell("Total");

                //            foreach (var item in orderItems)
                //            {
                //                var sneaker = getSneaker(item.sneaker_id);
                //                table.AddCell(sneaker.sneaker_name);
                //                table.AddCell(item.quantity.ToString());
                //                table.AddCell(item.price.ToString("C"));
                //                table.AddCell((item.price * item.quantity).ToString("C"));
                //            }

                //            doc.Add(table);
                //            doc.Add(new Paragraph(" "));
                //            doc.Add(new Paragraph($"Total Amount: {order.total_amount:C}", FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14)));

                //            doc.Close();

                //            return ms.ToArray();
                //        }
                //    }
                return null;
            }


            catch (Exception ex)
            {
                throw new FaultException("Failed to generate invoice: " + ex.Message);
            }
            }



     }
 } 

        
