﻿using SneakPeak.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SneakPeak
{

    public partial class Login : System.Web.UI.Page
    {
        //Datacontext
        DataClasses1DataContext db = new DataClasses1DataContext();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Service1Client client = new Service1Client();
            int UserId = client.Login(txtEmail.Text, txtPassword.Text, txtrole.Text);
            string role = txtrole.Text;
              if (UserId!=-1 && role == "Customer")
            {
                
                Response.Redirect("index.aspx");
            }
            if (UserId!=-1 && role == "Admin")
            {             
                Response.Redirect("AdminDashboard.aspx");
            }
           
            else
            {
                lblMessage.Text = "Invalid username or password!";
            }
        }
    }
}
