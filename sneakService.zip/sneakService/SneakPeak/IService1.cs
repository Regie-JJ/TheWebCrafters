﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SneakPeak
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {
       
        //user operations
        [OperationContract]
        int Login(string username, string password);

        [OperationContract]
        User getUser(int userId);
         [OperationContract]
        bool Register(string firstname, string lastname, string email, string password, String phone_no, string userType);
        // sneakers/product Operations
        [OperationContract]
        List<Sneaker> getSneakers();

        [OperationContract]
        Sneaker getSneaker(int Sneaker_id);

        [OperationContract]
        List<Sneaker> getSneakersByCategory(string categoryName);

        [OperationContract]
        bool AddSneaker(Sneaker sneaker);
        // Cart Operations
        [OperationContract]
        void CreateCart(int userId);

        [OperationContract]
        void AddItemToCart(int userId, int sneakerId);

        [OperationContract]
        void RemoveItemFromCart(int userId, int sneakerId);

        [OperationContract]
        Cart GetCart(int userId);

        [OperationContract]
        List<CartItem> GetCartItems(int cartId);

        [OperationContract]
        CartItem GetCartItem(int Id);

        [OperationContract]
        int CartItemsCount(int cartId);

        // Checkout and Orders
        [OperationContract]
        bool Checkout(int userId);
        // invoice operation
        [OperationContract]
        byte[] GenerateInvoice(int orderId);

    }
}
