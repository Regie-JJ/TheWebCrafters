﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SneakPeak.ServiceReference1;
namespace SneakPeak
{
    public partial class Signup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSignup_Click(object sender, EventArgs e)
        {
            Service1Client client = new Service1Client();

            User newUser = new User
            {
                first_name =txtFirstName.Text,
                last_name=txtLastName.Text,
                phone_number=txtPhone.Text,
                password = txtPassword.Text, // Will be hashed in service
                email= txtEmail.Text,
                user_type=txtusertype.Text,
            };

            bool success = client.Register(txtFirstName.Text,txtLastName.Text ,txtEmail.Text,txtPassword.Text,txtPhone.Text,txtusertype.Text);

            if (success)
            {
                lblmessage.Text = "Registration successful!";
                Response.Redirect("Login.aspx");
            }
            else
            {
                lblmessage.Text = "Registration failed. Try again.";
            }
        }
    }
}